==================================
Sun Grid Engine submission scripts
==================================

This directory contains submission scripts or commands to run the protocols on a Sun Grid Engine cluster.